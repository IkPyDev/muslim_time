# from utils.allUsers import allUser
# from loader import *
# from aiogram import Dispatcher
# import logging
# from aiogram.types import Message
# async def adminReklama(dp: Dispatcher,msg:Message):
#     for admin in allUser:
#         try:
#             await dp.bot.send_message(admin, msg)
#
#         except Exception as err:
#             logging.exception(err)
