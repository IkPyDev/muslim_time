from . import menuKeyboards
from . import namazKeyboards