# from environs import Env
import os
# # environs kutubxonasidan foydalanish
# env = Env()
# env.read_env()

# .env fayl ichidan quyidagilarni o'qiymiz
BOT_TOKEN ="5405581931:AAHobarl_zVkj5lEeWtvgH2A4xJ0o7ZF3zc" #str(os.environ.get("BOT_TOKEN"))  # Bot toekn
ADMINS=[986895511]
CHENELS = [-1001777080199]
#ADMINS =  list(os.environ.get("ADMINS")) 
